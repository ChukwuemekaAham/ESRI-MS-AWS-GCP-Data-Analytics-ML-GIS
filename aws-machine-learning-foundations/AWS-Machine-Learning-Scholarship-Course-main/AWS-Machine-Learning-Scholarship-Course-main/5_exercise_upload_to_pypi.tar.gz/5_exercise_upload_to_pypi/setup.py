from setuptools import setup

setup(name='dsnd_probability_distributions',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['dsnd_probability_distributions'],
      author = 'Jimoh Abdulganiyu',
      author_email = 'jimohabdulganiyuj@gmail.com',
      zip_safe=False)
